"""
Utility functions for the PhishGuard application
"""
