#!/usr/bin/env python3
"""
Configuration Utilities
Functions for loading and saving configuration
"""

import os
import json
import logging

logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_CONFIG = {
    'database': {
        'path': 'data/phishguard.db'
    },
    'model': {
        'path': 'resources/models/url_classifier.joblib'
    },
    'detection': {
        'phishing_threshold': 0.7,
        'suspicious_threshold': 0.4
    },
    'analysis': {
        'analyze_content': True,
        'request_timeout': 5,
        'force_reanalysis': False,
        'suspicious_tlds': [
            'xyz', 'top', 'club', 'online', 'site', 'work', 'info', 'stream'
        ],
        'suspicious_keywords': [
            'secure', 'account', 'banking', 'login', 'verify', 'update', 'confirm',
            'paypal', 'password', 'wallet', 'alert', 'purchase', 'transaction'
        ]
    },
    'ui': {
        'theme': 'system',
        'show_tooltips': True,
        'max_history_items': 100
    }
}

def load_config(config_path=None):
    """
    Load configuration from a JSON file
    
    Args:
        config_path (str, optional): Path to configuration file
        
    Returns:
        dict: Configuration dictionary
    """
    # Use default path if not specified
    if not config_path:
        config_path = 'config.json'
    
    # Start with default configuration
    config = DEFAULT_CONFIG.copy()
    
    # Load from file if it exists
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                file_config = json.load(f)
            
            # Update config with values from file
            _update_config(config, file_config)
            
            logger.info(f"Configuration loaded from {config_path}")
        except Exception as e:
            logger.error(f"Error loading configuration: {str(e)}")
    else:
        # Create default configuration file
        save_config(config, config_path)
        logger.info(f"Created default configuration at {config_path}")
    
    return config

def save_config(config, config_path=None):
    """
    Save configuration to a JSON file
    
    Args:
        config (dict): Configuration dictionary
        config_path (str, optional): Path to configuration file
        
    Returns:
        bool: True if successful, False otherwise
    """
    # Use default path if not specified
    if not config_path:
        config_path = 'config.json'
    
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=4)
        
        logger.info(f"Configuration saved to {config_path}")
        return True
    except Exception as e:
        logger.error(f"Error saving configuration: {str(e)}")
        return False

def get_default_config():
    """
    Get a copy of the default configuration
    
    Returns:
        dict: Default configuration
    """
    return DEFAULT_CONFIG.copy()

def _update_config(base_config, new_config):
    """
    Recursively update base_config with values from new_config
    
    Args:
        base_config (dict): Base configuration to update
        new_config (dict): New configuration values
    """
    for key, value in new_config.items():
        if isinstance(value, dict) and key in base_config and isinstance(base_config[key], dict):
            # Recursively update nested dictionaries
            _update_config(base_config[key], value)
        else:
            # Update value
            base_config[key] = value
