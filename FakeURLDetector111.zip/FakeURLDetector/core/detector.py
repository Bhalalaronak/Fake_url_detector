#!/usr/bin/env python3
"""
URL Detector
Core component for detecting fake/malicious URLs
"""

import os
import logging
import time
import joblib
import numpy as np
from datetime import datetime
from urllib.parse import urlparse

from .analyzer import URLAnalyzer
from .database import DatabaseManager

logger = logging.getLogger(__name__)

class URLDetector:
    """Detects fake/malicious URLs using machine learning and heuristic analysis"""
    
    def __init__(self, url_analyzer, db_manager, config):
        """
        Initialize the URL detector
        
        Args:
            url_analyzer (URLAnalyzer): URL analyzer instance
            db_manager (DatabaseManager): Database manager instance
            config (dict): Configuration dictionary
        """
        self.url_analyzer = url_analyzer
        self.db_manager = db_manager
        self.config = config
        
        # Load ML model
        self.model = self._load_model()
        
        # Detection thresholds
        self.phishing_threshold = config.get('detection', {}).get('phishing_threshold', 0.7)
        self.suspicious_threshold = config.get('detection', {}).get('suspicious_threshold', 0.4)
        
        logger.info("URL Detector initialized")
    
    def _load_model(self):
        """
        Load the machine learning model
        
        Returns:
            object: Loaded model or None if not available
        """
        model_path = self.config.get('model', {}).get('path', 'resources/models/url_classifier.joblib')
        
        if os.path.exists(model_path):
            try:
                model = joblib.load(model_path)
                logger.info(f"Model loaded from {model_path}")
                return model
            except Exception as e:
                logger.error(f"Error loading model: {str(e)}")
        else:
            logger.warning(f"Model file not found at {model_path}")
        
        return None
    
    def analyze_url(self, url):
        """
        Analyze a URL for signs of being fake/malicious
        
        Args:
            url (str): URL to analyze
            
        Returns:
            dict: Analysis results
        """
        start_time = time.time()
        
        # Check if URL has been analyzed before
        cached_result = self.db_manager.get_url_analysis(url)
        if cached_result and not self.config.get('analysis', {}).get('force_reanalysis', False):
            logger.info(f"Using cached analysis for {url}")
            cached_result['from_cache'] = True
            return cached_result
        
        # Basic URL validation
        if not self._is_valid_url(url):
            logger.warning(f"Invalid URL format: {url}")
            return {
                'url': url,
                'is_valid': False,
                'error': 'Invalid URL format',
                'timestamp': datetime.now().isoformat()
            }
        
        try:
            # Extract features for analysis
            features = self.url_analyzer.extract_features(url)
            
            # Get ML prediction if model is available
            prediction_score = 0
            if self.model:
                # Prepare features for the model
                model_features = self._prepare_model_features(features)
                
                # Get prediction
                prediction_score = self.model.predict_proba(model_features)[0][1]  # Probability of being malicious
            
            # Determine result based on prediction and heuristics
            result = self._determine_result(url, features, prediction_score)
            
            # Add analysis metadata
            result.update({
                'url': url,
                'is_valid': True,
                'features': features,
                'timestamp': datetime.now().isoformat(),
                'analysis_time': time.time() - start_time
            })
            
            # Store result in database
            self.db_manager.store_url_analysis(url, result)
            
            logger.info(f"URL analysis completed for {url}: {result['classification']}")
            return result
            
        except Exception as e:
            logger.error(f"Error analyzing URL {url}: {str(e)}", exc_info=True)
            return {
                'url': url,
                'is_valid': True,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
    
    def analyze_bulk_urls(self, urls):
        """
        Analyze multiple URLs
        
        Args:
            urls (list): List of URLs to analyze
            
        Returns:
            list: List of analysis results
        """
        results = []
        for url in urls:
            result = self.analyze_url(url)
            results.append(result)
        
        return results
    
    def _is_valid_url(self, url):
        """
        Check if a URL has valid format
        
        Args:
            url (str): URL to check
            
        Returns:
            bool: True if valid, False otherwise
        """
        try:
            result = urlparse(url)
            return all([result.scheme, result.netloc])
        except:
            return False
    
    def _prepare_model_features(self, features):
        """
        Prepare features for the machine learning model
        
        Args:
            features (dict): Features extracted from URL
            
        Returns:
            array: Feature array for model input
        """
        # This would normally extract and normalize the features expected by the model
        # For simplicity, we'll use a subset of features in a specific order
        feature_list = [
            features.get('url_length', 0),
            features.get('domain_length', 0),
            features.get('num_digits', 0),
            features.get('num_special_chars', 0),
            features.get('has_https', 0),
            features.get('has_suspicious_tld', 0),
            features.get('domain_age_days', 0),
            features.get('has_suspicious_keywords', 0),
            features.get('num_subdomains', 0),
            features.get('path_length', 0)
        ]
        
        return np.array([feature_list])
    
    def _determine_result(self, url, features, prediction_score):
        """
        Determine the final result based on prediction and heuristics
        
        Args:
            url (str): Analyzed URL
            features (dict): Extracted features
            prediction_score (float): ML prediction score
            
        Returns:
            dict: Result dictionary
        """
        # Initialize result
        result = {
            'prediction_score': prediction_score,
            'risk_factors': [],
            'safety_factors': []
        }
        
        # Check for risk factors
        if features.get('has_suspicious_tld', False):
            result['risk_factors'].append('Suspicious top-level domain')
        
        if features.get('has_suspicious_keywords', False):
            result['risk_factors'].append('Contains suspicious keywords')
        
        if features.get('domain_age_days', 365) < 30:
            result['risk_factors'].append('Domain registered recently')
        
        if features.get('url_length', 0) > 100:
            result['risk_factors'].append('Unusually long URL')
        
        if features.get('num_subdomains', 0) > 3:
            result['risk_factors'].append('Multiple subdomains')
        
        if features.get('num_special_chars', 0) > 5:
            result['risk_factors'].append('High number of special characters')
        
        # Check for safety factors
        if features.get('has_https', False):
            result['safety_factors'].append('Uses HTTPS')
        
        if features.get('domain_age_days', 0) > 365:
            result['safety_factors'].append('Domain older than 1 year')
        
        if features.get('has_valid_ssl', False):
            result['safety_factors'].append('Valid SSL certificate')
        
        # Determine classification based on prediction score and factors
        if prediction_score >= self.phishing_threshold or len(result['risk_factors']) >= 3:
            result['classification'] = 'Phishing'
            result['confidence'] = max(prediction_score, 0.7)
        elif prediction_score >= self.suspicious_threshold or len(result['risk_factors']) >= 1:
            result['classification'] = 'Suspicious'
            result['confidence'] = max(prediction_score, 0.4)
        else:
            result['classification'] = 'Legitimate'
            result['confidence'] = 1.0 - prediction_score
        
        return result
