#!/usr/bin/env python3
"""
Database Manager
Handles database operations for URL analysis storage
"""

import os
import json
import sqlite3
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class DatabaseManager:
    """Manages database operations for URL analysis storage"""
    
    def __init__(self, db_path):
        """
        Initialize the database manager
        
        Args:
            db_path (str): Path to the SQLite database file
        """
        self.db_path = db_path
        
        # Create database directory if it doesn't exist
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        # Initialize database
        self._init_db()
        
        logger.info(f"Database initialized at {db_path}")
    
    def _init_db(self):
        """Initialize the database schema"""
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Create URL analysis table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS url_analysis (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT NOT NULL,
                    classification TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    prediction_score REAL NOT NULL,
                    analysis_data TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    UNIQUE(url)
                )
            ''')
            
            # Create analysis history table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS analysis_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    url TEXT NOT NULL,
                    classification TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    timestamp TEXT NOT NULL,
                    FOREIGN KEY (url) REFERENCES url_analysis(url)
                )
            ''')
            
            conn.commit()
        
        except sqlite3.Error as e:
            logger.error(f"Database initialization error: {str(e)}")
        
        finally:
            if conn:
                conn.close()
    
    def store_url_analysis(self, url, analysis_result):
        """
        Store URL analysis result in the database
        
        Args:
            url (str): Analyzed URL
            analysis_result (dict): Analysis result
            
        Returns:
            bool: True if successful, False otherwise
        """
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Extract key data
            classification = analysis_result.get('classification', 'Unknown')
            confidence = analysis_result.get('confidence', 0.0)
            prediction_score = analysis_result.get('prediction_score', 0.0)
            timestamp = analysis_result.get('timestamp', datetime.now().isoformat())
            
            # Convert analysis data to JSON
            analysis_data = json.dumps(analysis_result)
            
            # Insert or replace in url_analysis table
            cursor.execute('''
                INSERT OR REPLACE INTO url_analysis 
                (url, classification, confidence, prediction_score, analysis_data, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (url, classification, confidence, prediction_score, analysis_data, timestamp))
            
            # Add to history
            cursor.execute('''
                INSERT INTO analysis_history 
                (url, classification, confidence, timestamp)
                VALUES (?, ?, ?, ?)
            ''', (url, classification, confidence, timestamp))
            
            conn.commit()
            logger.debug(f"Stored analysis for URL: {url}")
            return True
        
        except sqlite3.Error as e:
            logger.error(f"Database error storing URL analysis: {str(e)}")
            return False
        
        finally:
            if conn:
                conn.close()
    
    def get_url_analysis(self, url):
        """
        Get URL analysis result from the database
        
        Args:
            url (str): URL to retrieve
            
        Returns:
            dict: Analysis result or None if not found
        """
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Query the database
            cursor.execute('''
                SELECT analysis_data FROM url_analysis
                WHERE url = ?
            ''', (url,))
            
            result = cursor.fetchone()
            
            if result:
                # Parse JSON data
                analysis_data = json.loads(result[0])
                logger.debug(f"Retrieved analysis for URL: {url}")
                return analysis_data
            else:
                logger.debug(f"No analysis found for URL: {url}")
                return None
        
        except sqlite3.Error as e:
            logger.error(f"Database error retrieving URL analysis: {str(e)}")
            return None
        
        finally:
            if conn:
                conn.close()
    
    def get_analysis_history(self, limit=100):
        """
        Get analysis history
        
        Args:
            limit (int): Maximum number of records to retrieve
            
        Returns:
            list: List of analysis history records
        """
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            conn.row_factory = sqlite3.Row  # Return rows as dictionaries
            cursor = conn.cursor()
            
            # Query the database
            cursor.execute('''
                SELECT url, classification, confidence, timestamp
                FROM analysis_history
                ORDER BY timestamp DESC
                LIMIT ?
            ''', (limit,))
            
            results = cursor.fetchall()
            
            # Convert to list of dictionaries
            history = [dict(row) for row in results]
            
            logger.debug(f"Retrieved {len(history)} analysis history records")
            return history
        
        except sqlite3.Error as e:
            logger.error(f"Database error retrieving analysis history: {str(e)}")
            return []
        
        finally:
            if conn:
                conn.close()
    
    def get_statistics(self):
        """
        Get analysis statistics
        
        Returns:
            dict: Statistics dictionary
        """
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Get total count
            cursor.execute("SELECT COUNT(*) FROM url_analysis")
            total_count = cursor.fetchone()[0]
            
            # Get counts by classification
            cursor.execute('''
                SELECT classification, COUNT(*) 
                FROM url_analysis 
                GROUP BY classification
            ''')
            classification_counts = {row[0]: row[1] for row in cursor.fetchall()}
            
            # Get recent analysis count
            recent_timestamp = (datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)).isoformat()
            cursor.execute('''
                SELECT COUNT(*) FROM analysis_history
                WHERE timestamp >= ?
            ''', (recent_timestamp,))
            recent_count = cursor.fetchone()[0]
            
            statistics = {
                'total_analyzed': total_count,
                'classification_counts': classification_counts,
                'recent_count': recent_count
            }
            
            logger.debug("Retrieved analysis statistics")
            return statistics
        
        except sqlite3.Error as e:
            logger.error(f"Database error retrieving statistics: {str(e)}")
            return {
                'total_analyzed': 0,
                'classification_counts': {},
                'recent_count': 0
            }
        
        finally:
            if conn:
                conn.close()
    
    def clear_history(self):
        """
        Clear analysis history
        
        Returns:
            bool: True if successful, False otherwise
        """
        conn = None
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Delete all records from analysis_history
            cursor.execute("DELETE FROM analysis_history")
            
            conn.commit()
            logger.info("Analysis history cleared")
            return True
        
        except sqlite3.Error as e:
            logger.error(f"Database error clearing history: {str(e)}")
            return False
        
        finally:
            if conn:
                conn.close()
