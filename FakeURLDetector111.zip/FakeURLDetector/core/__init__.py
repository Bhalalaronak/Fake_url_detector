"""
Core components for the PhishGuard application
"""
