#!/usr/bin/env python3
"""
URL Analyzer
Extracts features from URLs for analysis
"""

import re
import logging
import tldextract
import whois
import requests
import validators
from urllib.parse import urlparse
from datetime import datetime
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)

class URLAnalyzer:
    """Analyzes URLs and extracts features for detection"""
    
    def __init__(self, config):
        """
        Initialize the URL analyzer
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        
        # Load suspicious TLDs
        self.suspicious_tlds = config.get('analysis', {}).get('suspicious_tlds', [
            'xyz', 'top', 'club', 'online', 'site', 'work', 'info', 'stream'
        ])
        
        # Load suspicious keywords
        self.suspicious_keywords = config.get('analysis', {}).get('suspicious_keywords', [
            'secure', 'account', 'banking', 'login', 'verify', 'update', 'confirm',
            'paypal', 'password', 'wallet', 'alert', 'purchase', 'transaction'
        ])
        
        # Request headers
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        # Request timeout
        self.timeout = config.get('analysis', {}).get('request_timeout', 5)
        
        logger.info("URL Analyzer initialized")
    
    def extract_features(self, url):
        """
        Extract features from a URL
        
        Args:
            url (str): URL to analyze
            
        Returns:
            dict: Extracted features
        """
        features = {}
        
        # Parse URL
        parsed_url = urlparse(url)
        extracted = tldextract.extract(url)
        
        # Basic URL features
        features['url_length'] = len(url)
        features['domain'] = f"{extracted.domain}.{extracted.suffix}"
        features['domain_length'] = len(features['domain'])
        features['tld'] = extracted.suffix
        features['subdomain'] = extracted.subdomain
        features['path'] = parsed_url.path
        features['path_length'] = len(parsed_url.path)
        features['num_subdomains'] = len(extracted.subdomain.split('.')) if extracted.subdomain else 0
        
        # Character-based features
        features['num_digits'] = sum(c.isdigit() for c in url)
        features['num_letters'] = sum(c.isalpha() for c in url)
        features['num_special_chars'] = sum(not c.isalnum() for c in url)
        
        # Security features
        features['has_https'] = parsed_url.scheme == 'https'
        features['has_suspicious_tld'] = extracted.suffix in self.suspicious_tlds
        features['has_suspicious_keywords'] = any(keyword in url.lower() for keyword in self.suspicious_keywords)
        
        # Domain information
        domain_info = self._get_domain_info(features['domain'])
        features.update(domain_info)
        
        # Content features (if enabled)
        if self.config.get('analysis', {}).get('analyze_content', True):
            content_features = self._analyze_content(url)
            features.update(content_features)
        
        return features
    
    def _get_domain_info(self, domain):
        """
        Get information about a domain
        
        Args:
            domain (str): Domain to analyze
            
        Returns:
            dict: Domain information
        """
        info = {
            'domain_age_days': 0,
            'domain_expiry_days': 0,
            'domain_registrar': 'Unknown',
            'whois_available': False
        }
        
        try:
            # Get WHOIS information
            domain_whois = whois.whois(domain)
            info['whois_available'] = True
            
            # Get creation date
            if domain_whois.creation_date:
                creation_date = domain_whois.creation_date
                if isinstance(creation_date, list):
                    creation_date = creation_date[0]
                
                # Calculate domain age
                age = (datetime.now() - creation_date).days
                info['domain_age_days'] = max(0, age)  # Ensure non-negative
            
            # Get expiration date
            if domain_whois.expiration_date:
                expiry_date = domain_whois.expiration_date
                if isinstance(expiry_date, list):
                    expiry_date = expiry_date[0]
                
                # Calculate days until expiry
                days_to_expiry = (expiry_date - datetime.now()).days
                info['domain_expiry_days'] = max(0, days_to_expiry)  # Ensure non-negative
            
            # Get registrar
            if domain_whois.registrar:
                info['domain_registrar'] = domain_whois.registrar
        
        except Exception as e:
            logger.warning(f"Error getting WHOIS information for {domain}: {str(e)}")
        
        return info
    
    def _analyze_content(self, url):
        """
        Analyze the content of a webpage
        
        Args:
            url (str): URL to analyze
            
        Returns:
            dict: Content features
        """
        features = {
            'content_available': False,
            'has_login_form': False,
            'has_password_field': False,
            'num_external_links': 0,
            'num_images': 0,
            'has_valid_ssl': False
        }
        
        try:
            # Make request to the URL
            response = requests.get(url, headers=self.headers, timeout=self.timeout, verify=True)
            features['content_available'] = True
            
            # Check SSL certificate
            features['has_valid_ssl'] = response.url.startswith('https')
            
            # Parse HTML content
            soup = BeautifulSoup(response.text, 'lxml')
            
            # Check for login forms
            forms = soup.find_all('form')
            for form in forms:
                action = form.get('action', '').lower()
                if 'login' in action or 'signin' in action or 'auth' in action:
                    features['has_login_form'] = True
                    break
            
            # Check for password fields
            password_fields = soup.find_all('input', {'type': 'password'})
            features['has_password_field'] = len(password_fields) > 0
            
            # Count external links
            links = soup.find_all('a', href=True)
            base_domain = tldextract.extract(url).registered_domain
            external_links = [link for link in links if base_domain not in link.get('href', '')]
            features['num_external_links'] = len(external_links)
            
            # Count images
            images = soup.find_all('img')
            features['num_images'] = len(images)
        
        except requests.exceptions.SSLError:
            features['has_valid_ssl'] = False
            logger.warning(f"SSL certificate validation failed for {url}")
        
        except Exception as e:
            logger.warning(f"Error analyzing content for {url}: {str(e)}")
        
        return features
    
    def get_screenshot(self, url):
        """
        Get a screenshot of a webpage (placeholder)
        
        Args:
            url (str): URL to screenshot
            
        Returns:
            bytes: Screenshot image data or None if not available
        """
        # This would normally use a headless browser like Selenium or Playwright
        # For simplicity, we'll return None
        logger.info(f"Screenshot requested for {url} (not implemented)")
        return None
    
    def compare_with_legitimate(self, url, legitimate_url):
        """
        Compare a URL with a known legitimate URL
        
        Args:
            url (str): URL to analyze
            legitimate_url (str): Known legitimate URL for comparison
            
        Returns:
            dict: Comparison results
        """
        # Extract features for both URLs
        features1 = self.extract_features(url)
        features2 = self.extract_features(legitimate_url)
        
        # Calculate similarity score (simple example)
        similarity = self._calculate_similarity(features1, features2)
        
        return {
            'similarity_score': similarity,
            'is_similar': similarity > 0.7,
            'legitimate_url': legitimate_url,
            'analyzed_url': url
        }
    
    def _calculate_similarity(self, features1, features2):
        """
        Calculate similarity between two feature sets
        
        Args:
            features1 (dict): First feature set
            features2 (dict): Second feature set
            
        Returns:
            float: Similarity score (0-1)
        """
        # This is a simplified similarity calculation
        # A real implementation would use more sophisticated methods
        
        # Compare domain names using Levenshtein distance
        from difflib import SequenceMatcher
        
        domain1 = features1.get('domain', '')
        domain2 = features2.get('domain', '')
        
        # Calculate string similarity
        matcher = SequenceMatcher(None, domain1, domain2)
        domain_similarity = matcher.ratio()
        
        # More weight to domain similarity
        return domain_similarity
