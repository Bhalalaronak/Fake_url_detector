# PhishGuard - Advanced Fake URL Detection Tool

![PhishGuard Logo](resources/images/logo.png)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)

PhishGuard is an advanced cybersecurity tool designed to detect and analyze potentially malicious URLs, phishing websites, and fake domains. With its powerful machine learning algorithms and comprehensive analysis features, PhishGuard helps security professionals and everyday users identify threats before they cause harm.

![Screenshot](resources/images/screenshot.png)

## Features

- **Real-time URL Analysis**: Instantly analyze URLs for signs of phishing or malicious intent
- **Machine Learning Detection**: Utilizes trained ML models to identify fake URLs with high accuracy
- **Comprehensive Domain Analysis**:
  - WHOIS information retrieval
  - SSL certificate validation
  - Domain age verification
  - Suspicious TLD detection
- **Visual Analysis**:
  - URL structure breakdown
  - Visual similarity comparison with legitimate sites
  - Screenshot comparison
- **Bulk URL Scanning**: Process multiple URLs from files or clipboard
- **Detailed Reports**: Generate comprehensive PDF or HTML reports
- **Historical Database**: Keep track of previously analyzed URLs
- **Browser Integration**: Optional browser extension for real-time protection

## Installation

### Prerequisites
- Python 3.8 or higher
- pip package manager

### Setup

1. Clone the repository:
```bash
git clone https://github.com/yourusername/phishguard.git
cd phishguard
```

2. Create a virtual environment (recommended):
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
python main.py
```

## Usage

### GUI Application

1. Launch the application:
```bash
python main.py
```

2. Enter a URL in the input field or paste from clipboard
3. Click "Analyze" to start the detection process
4. Review the detailed analysis results
5. Save or export the report if needed

### Command Line Interface

For batch processing or integration with other tools:

```bash
python cli.py --url https://example.com
python cli.py --file urls.txt
python cli.py --bulk "https://example1.com https://example2.com"
```

## How It Works

PhishGuard uses a multi-layered approach to detect fake and malicious URLs:

1. **URL Structure Analysis**: Examines URL components for suspicious patterns
2. **Domain Analysis**: Checks domain registration, age, and reputation
3. **Content Analysis**: Analyzes webpage content for phishing indicators
4. **Machine Learning Classification**: Uses trained models to classify URLs based on multiple features
5. **Visual Similarity**: Compares visual appearance with known legitimate sites

## Machine Learning Model

The core detection engine uses a gradient boosting classifier trained on a dataset of over 50,000 URLs (both legitimate and malicious). Features include:

- URL length and character distribution
- Domain age and registration details
- TLD reputation score
- Presence of suspicious keywords
- SSL certificate validity
- Lexical features of the URL
- Host-based features

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Acknowledgments

- [WHOIS Python](https://github.com/richardpenman/whois) for domain information retrieval
- [Beautiful Soup](https://www.crummy.com/software/BeautifulSoup/) for HTML parsing
- [scikit-learn](https://scikit-learn.org/) for machine learning capabilities
- [PyQt5](https://www.riverbankcomputing.com/software/pyqt/) for the GUI framework

## Disclaimer

This tool is for educational and defensive security purposes only. Always respect privacy and applicable laws when using this software.
