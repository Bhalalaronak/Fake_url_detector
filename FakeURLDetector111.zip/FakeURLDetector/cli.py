#!/usr/bin/env python3
"""
PhishGuard - Advanced Fake URL Detection Tool
Command Line Interface
"""

import sys
import os
import argparse
import logging
import json
from datetime import datetime
from dotenv import load_dotenv

from core.detector import URLDetector
from core.analyzer import URLAnalyzer
from core.database import DatabaseManager
from utils.config import load_config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("phishguard_cli.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("PhishGuard-CLI")

def parse_arguments():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="PhishGuard - Advanced Fake URL Detection Tool")
    
    # URL input options
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--url', '-u', help='URL to analyze')
    group.add_argument('--file', '-f', help='File containing URLs to analyze (one per line)')
    group.add_argument('--bulk', '-b', help='Space-separated list of URLs to analyze')
    
    # Output options
    parser.add_argument('--output', '-o', help='Output file for results')
    parser.add_argument('--format', choices=['text', 'json', 'csv'], default='text',
                      help='Output format (default: text)')
    
    # Analysis options
    parser.add_argument('--no-content', action='store_true', help='Skip content analysis')
    parser.add_argument('--timeout', type=int, default=5, help='Request timeout in seconds')
    
    # Verbose output
    parser.add_argument('--verbose', '-v', action='store_true', help='Enable verbose output')
    
    return parser.parse_args()

def analyze_url(url_detector, url, analyze_content=True, timeout=5):
    """
    Analyze a single URL
    
    Args:
        url_detector: URL detector instance
        url (str): URL to analyze
        analyze_content (bool): Whether to analyze page content
        timeout (int): Request timeout in seconds
        
    Returns:
        dict: Analysis result
    """
    # Update configuration for this analysis
    url_detector.url_analyzer.config['analysis']['analyze_content'] = analyze_content
    url_detector.url_analyzer.timeout = timeout
    
    # Analyze URL
    result = url_detector.analyze_url(url)
    return result

def analyze_urls_from_file(url_detector, file_path, analyze_content=True, timeout=5):
    """
    Analyze URLs from a file
    
    Args:
        url_detector: URL detector instance
        file_path (str): Path to file containing URLs
        analyze_content (bool): Whether to analyze page content
        timeout (int): Request timeout in seconds
        
    Returns:
        list: List of analysis results
    """
    results = []
    
    try:
        with open(file_path, 'r') as f:
            urls = [line.strip() for line in f if line.strip()]
        
        # Process each URL
        for url in urls:
            result = analyze_url(url_detector, url, analyze_content, timeout)
            results.append(result)
            
            # Print progress
            classification = result.get('classification', 'Unknown')
            print(f"Analyzed: {url} - {classification}")
    
    except Exception as e:
        logger.error(f"Error processing URL file: {str(e)}")
    
    return results

def format_output(results, output_format):
    """
    Format analysis results
    
    Args:
        results (list): List of analysis results
        output_format (str): Output format ('text', 'json', or 'csv')
        
    Returns:
        str: Formatted output
    """
    if output_format == 'json':
        return json.dumps(results, indent=2, default=str)
    
    elif output_format == 'csv':
        # Create CSV header
        csv_output = "URL,Classification,Confidence,Risk Factors,Safety Factors\n"
        
        # Add data rows
        for result in results:
            url = result.get('url', 'Unknown')
            classification = result.get('classification', 'Unknown')
            confidence = result.get('confidence', 0.0)
            risk_factors = "|".join(result.get('risk_factors', []))
            safety_factors = "|".join(result.get('safety_factors', []))
            
            csv_output += f'"{url}","{classification}",{confidence},"{risk_factors}","{safety_factors}"\n'
        
        return csv_output
    
    else:  # text format
        text_output = "PhishGuard Analysis Results\n"
        text_output += "=========================\n\n"
        
        for i, result in enumerate(results):
            url = result.get('url', 'Unknown')
            classification = result.get('classification', 'Unknown')
            confidence = result.get('confidence', 0.0)
            
            text_output += f"URL {i+1}: {url}\n"
            text_output += f"Classification: {classification}\n"
            text_output += f"Confidence: {confidence:.1%}\n"
            
            text_output += "Risk Factors:\n"
            risk_factors = result.get('risk_factors', [])
            if risk_factors:
                for factor in risk_factors:
                    text_output += f"- {factor}\n"
            else:
                text_output += "- None detected\n"
            
            text_output += "Safety Factors:\n"
            safety_factors = result.get('safety_factors', [])
            if safety_factors:
                for factor in safety_factors:
                    text_output += f"- {factor}\n"
            else:
                text_output += "- None detected\n"
            
            text_output += "\n"
        
        text_output += f"Analysis completed at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        return text_output

def main():
    """Main function"""
    # Parse arguments
    args = parse_arguments()
    
    # Set log level
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Load environment variables
    load_dotenv()
    
    # Load configuration
    config = load_config()
    
    # Initialize components
    db_manager = DatabaseManager(config.get('database', {}).get('path', 'data/phishguard.db'))
    url_analyzer = URLAnalyzer(config)
    url_detector = URLDetector(url_analyzer, db_manager, config)
    
    # Process URLs
    results = []
    
    if args.url:
        # Analyze single URL
        result = analyze_url(url_detector, args.url, not args.no_content, args.timeout)
        results = [result]
        
        # Print result
        classification = result.get('classification', 'Unknown')
        confidence = result.get('confidence', 0.0)
        print(f"URL: {args.url}")
        print(f"Classification: {classification}")
        print(f"Confidence: {confidence:.1%}")
        
        # Print risk factors
        print("Risk Factors:")
        risk_factors = result.get('risk_factors', [])
        if risk_factors:
            for factor in risk_factors:
                print(f"- {factor}")
        else:
            print("- None detected")
    
    elif args.file:
        # Analyze URLs from file
        results = analyze_urls_from_file(url_detector, args.file, not args.no_content, args.timeout)
        print(f"Analyzed {len(results)} URLs from file")
    
    elif args.bulk:
        # Analyze bulk URLs
        urls = args.bulk.split()
        for url in urls:
            result = analyze_url(url_detector, url, not args.no_content, args.timeout)
            results.append(result)
            
            # Print progress
            classification = result.get('classification', 'Unknown')
            print(f"Analyzed: {url} - {classification}")
        
        print(f"Analyzed {len(results)} URLs")
    
    # Output results
    if args.output:
        try:
            # Format output
            output = format_output(results, args.format)
            
            # Write to file
            with open(args.output, 'w') as f:
                f.write(output)
            
            print(f"Results saved to {args.output}")
        
        except Exception as e:
            logger.error(f"Error saving results: {str(e)}")
            print(f"Error saving results: {str(e)}")

if __name__ == "__main__":
    main()
