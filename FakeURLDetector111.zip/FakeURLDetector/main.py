#!/usr/bin/env python3
"""
PhishGuard - Advanced Fake URL Detection Tool
Main application entry point
"""

import sys
import os
import logging
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
from dotenv import load_dotenv

from gui.main_window import MainWindow
from core.detector import URLDetector
from core.analyzer import URLAnalyzer
from core.database import DatabaseManager
from utils.config import load_config

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("phishguard.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("PhishGuard")

def check_dependencies():
    """Check if all required dependencies are available"""
    try:
        import requests
        import bs4
        import tldextract
        import sklearn
        import numpy
        import pandas
        import whois
        import validators
        logger.info("All dependencies are available")
        return True
    except ImportError as e:
        logger.error(f"Missing dependency: {str(e)}")
        return False

def main():
    """Main application entry point"""
    # Load environment variables
    load_dotenv()
    
    # Load configuration
    config = load_config()
    
    # Check dependencies
    if not check_dependencies():
        print("Error: Missing dependencies. Please run 'pip install -r requirements.txt'")
        sys.exit(1)
    
    # Initialize components
    db_manager = DatabaseManager(config.get('database', {}).get('path', 'data/phishguard.db'))
    url_analyzer = URLAnalyzer(config)
    url_detector = URLDetector(url_analyzer, db_manager, config)
    
    # Create Qt application
    app = QApplication(sys.argv)
    app.setApplicationName("PhishGuard")
    app.setStyle('Fusion')  # Use Fusion style for consistent look across platforms
    
    # Enable high DPI scaling
    app.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    app.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    # Create and show main window
    main_window = MainWindow(url_detector, config)
    main_window.show()
    
    # Start the application event loop
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
