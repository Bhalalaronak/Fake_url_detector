#!/usr/bin/env python3
"""
Bulk Analysis Tab
Tab for analyzing multiple URLs
"""

import logging
import threading
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                            QTextEdit, QProgressBar, QGroupBox, QFormLayout, QLineEdit,
                            QTableWidget, QTableWidgetItem, QHeaderView, QFileDialog,
                            QMessageBox, QCheckBox)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt, QThread, pyqtSignal

logger = logging.getLogger(__name__)

class BulkAnalysisThread(QThread):
    """Thread for bulk URL analysis to prevent GUI freezing"""
    
    # Define signals
    progress_signal = pyqtSignal(int, int)  # current, total
    result_signal = pyqtSignal(dict)  # analysis result
    finished_signal = pyqtSignal()
    
    def __init__(self, url_detector, urls):
        """
        Initialize the bulk analysis thread
        
        Args:
            url_detector: URL detector instance
            urls (list): List of URLs to analyze
        """
        super().__init__()
        self.url_detector = url_detector
        self.urls = urls
    
    def run(self):
        """Run the analysis"""
        total = len(self.urls)
        
        for i, url in enumerate(self.urls):
            try:
                # Analyze URL
                result = self.url_detector.analyze_url(url)
                
                # Emit result
                self.result_signal.emit(result)
                
                # Emit progress
                self.progress_signal.emit(i + 1, total)
            
            except Exception as e:
                logger.error(f"Error analyzing URL {url}: {str(e)}")
        
        # Emit finished signal
        self.finished_signal.emit()

class BulkAnalysisTab(QWidget):
    """Tab for analyzing multiple URLs"""
    
    def __init__(self, url_detector):
        """
        Initialize the bulk analysis tab
        
        Args:
            url_detector: URL detector instance
        """
        super().__init__()
        
        self.url_detector = url_detector
        self.results = []
        
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        # Create main layout
        main_layout = QVBoxLayout()
        
        # Create URL input section
        input_group = QGroupBox("URLs to Analyze")
        input_layout = QVBoxLayout()
        
        # URL input text area
        self.url_input = QTextEdit()
        self.url_input.setPlaceholderText("Enter URLs to analyze (one per line)")
        input_layout.addWidget(self.url_input)
        
        # Create button layout
        button_layout = QHBoxLayout()
        
        # Load from file button
        load_button = QPushButton("Load from File")
        load_button.clicked.connect(self.load_from_file)
        button_layout.addWidget(load_button)
        
        # Paste from clipboard button
        paste_button = QPushButton("Paste from Clipboard")
        paste_button.clicked.connect(self.paste_from_clipboard)
        button_layout.addWidget(paste_button)
        
        # Clear button
        clear_button = QPushButton("Clear")
        clear_button.clicked.connect(self.clear_input)
        button_layout.addWidget(clear_button)
        
        input_layout.addLayout(button_layout)
        
        # Options layout
        options_layout = QHBoxLayout()
        
        # Analyze content checkbox
        self.analyze_content_checkbox = QCheckBox("Analyze Page Content")
        self.analyze_content_checkbox.setChecked(True)
        options_layout.addWidget(self.analyze_content_checkbox)
        
        # Add to history checkbox
        self.add_to_history_checkbox = QCheckBox("Add to History")
        self.add_to_history_checkbox.setChecked(True)
        options_layout.addWidget(self.add_to_history_checkbox)
        
        input_layout.addLayout(options_layout)
        
        # Start analysis button
        self.analyze_button = QPushButton("Start Analysis")
        self.analyze_button.clicked.connect(self.start_analysis)
        input_layout.addWidget(self.analyze_button)
        
        input_group.setLayout(input_layout)
        main_layout.addWidget(input_group)
        
        # Create progress section
        progress_group = QGroupBox("Analysis Progress")
        progress_layout = QVBoxLayout()
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        progress_layout.addWidget(self.progress_bar)
        
        # Progress label
        self.progress_label = QLabel("Ready")
        self.progress_label.setAlignment(Qt.AlignCenter)
        progress_layout.addWidget(self.progress_label)
        
        progress_group.setLayout(progress_layout)
        main_layout.addWidget(progress_group)
        
        # Create results section
        results_group = QGroupBox("Analysis Results")
        results_layout = QVBoxLayout()
        
        # Results table
        self.results_table = QTableWidget()
        self.results_table.setColumnCount(4)
        self.results_table.setHorizontalHeaderLabels(["URL", "Classification", "Confidence", "Risk Factors"])
        
        # Set column widths
        self.results_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.results_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.results_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.results_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        
        results_layout.addWidget(self.results_table)
        
        # Create summary layout
        summary_layout = QHBoxLayout()
        
        # Summary labels
        self.total_label = QLabel("Total: 0")
        summary_layout.addWidget(self.total_label)
        
        self.phishing_label = QLabel("Phishing: 0")
        self.phishing_label.setStyleSheet("color: red;")
        summary_layout.addWidget(self.phishing_label)
        
        self.suspicious_label = QLabel("Suspicious: 0")
        self.suspicious_label.setStyleSheet("color: orange;")
        summary_layout.addWidget(self.suspicious_label)
        
        self.legitimate_label = QLabel("Legitimate: 0")
        self.legitimate_label.setStyleSheet("color: green;")
        summary_layout.addWidget(self.legitimate_label)
        
        summary_layout.addStretch()
        
        # Export button
        export_button = QPushButton("Export Results")
        export_button.clicked.connect(self.export_results)
        summary_layout.addWidget(export_button)
        
        results_layout.addLayout(summary_layout)
        
        results_group.setLayout(results_layout)
        main_layout.addWidget(results_group, 1)  # Give it stretch factor
        
        self.setLayout(main_layout)
    
    def load_from_file(self):
        """Load URLs from a file"""
        # Open file dialog
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Load URLs from File", "", "Text Files (*.txt);;CSV Files (*.csv);;All Files (*)"
        )
        
        if not file_path:
            return
        
        try:
            # Read URLs from file
            with open(file_path, 'r') as f:
                urls = [line.strip() for line in f if line.strip()]
            
            # Set URLs in text area
            self.url_input.setText("\n".join(urls))
            
            # Update status
            self.progress_label.setText(f"Loaded {len(urls)} URLs from file")
            
            logger.info(f"Loaded {len(urls)} URLs from {file_path}")
        
        except Exception as e:
            logger.error(f"Error loading URLs from file: {str(e)}")
            QMessageBox.critical(self, "Load Error", f"Error loading URLs from file: {str(e)}")
    
    def paste_from_clipboard(self):
        """Paste URLs from clipboard"""
        # Get clipboard text
        clipboard = QApplication.clipboard()
        text = clipboard.text()
        
        if not text:
            return
        
        # Split into lines and filter empty lines
        urls = [line.strip() for line in text.split('\n') if line.strip()]
        
        # Set URLs in text area
        self.url_input.setText("\n".join(urls))
        
        # Update status
        self.progress_label.setText(f"Pasted {len(urls)} URLs from clipboard")
    
    def clear_input(self):
        """Clear URL input"""
        self.url_input.clear()
        self.progress_label.setText("Ready")
    
    def start_analysis(self):
        """Start bulk URL analysis"""
        # Get URLs from input
        text = self.url_input.toPlainText()
        urls = [line.strip() for line in text.split('\n') if line.strip()]
        
        if not urls:
            QMessageBox.warning(self, "Input Error", "Please enter URLs to analyze.")
            return
        
        # Add http:// to URLs that don't have a scheme
        urls = [url if url.startswith(('http://', 'https://')) else f"http://{url}" for url in urls]
        
        # Clear previous results
        self.results = []
        self.results_table.setRowCount(0)
        self.update_summary()
        
        # Reset progress
        self.progress_bar.setValue(0)
        self.progress_label.setText(f"Analyzing {len(urls)} URLs...")
        
        # Disable analyze button
        self.analyze_button.setEnabled(False)
        
        # Create and start analysis thread
        self.analysis_thread = BulkAnalysisThread(self.url_detector, urls)
        self.analysis_thread.progress_signal.connect(self.update_progress)
        self.analysis_thread.result_signal.connect(self.add_result)
        self.analysis_thread.finished_signal.connect(self.analysis_finished)
        self.analysis_thread.start()
        
        logger.info(f"Started bulk analysis of {len(urls)} URLs")
    
    def update_progress(self, current, total):
        """
        Update progress bar
        
        Args:
            current (int): Current progress
            total (int): Total items
        """
        # Calculate percentage
        percentage = int((current / total) * 100) if total > 0 else 0
        
        # Update progress bar
        self.progress_bar.setValue(percentage)
        
        # Update progress label
        self.progress_label.setText(f"Analyzed {current} of {total} URLs ({percentage}%)")
    
    def add_result(self, result):
        """
        Add a result to the results table
        
        Args:
            result (dict): Analysis result
        """
        # Add to results list
        self.results.append(result)
        
        # Add to table
        row = self.results_table.rowCount()
        self.results_table.insertRow(row)
        
        # URL
        url_item = QTableWidgetItem(result.get('url', 'Unknown'))
        self.results_table.setItem(row, 0, url_item)
        
        # Classification
        classification = result.get('classification', 'Unknown')
        classification_item = QTableWidgetItem(classification)
        
        # Set color based on classification
        if classification == 'Phishing':
            classification_item.setForeground(QColor('red'))
        elif classification == 'Suspicious':
            classification_item.setForeground(QColor('orange'))
        else:
            classification_item.setForeground(QColor('green'))
        
        self.results_table.setItem(row, 1, classification_item)
        
        # Confidence
        confidence = result.get('confidence', 0.0)
        confidence_item = QTableWidgetItem(f"{confidence:.1%}")
        self.results_table.setItem(row, 2, confidence_item)
        
        # Risk factors
        risk_factors = result.get('risk_factors', [])
        risk_factors_text = ", ".join(risk_factors) if risk_factors else "None"
        risk_factors_item = QTableWidgetItem(risk_factors_text)
        self.results_table.setItem(row, 3, risk_factors_item)
        
        # Update summary
        self.update_summary()
    
    def analysis_finished(self):
        """Handle completion of analysis"""
        # Enable analyze button
        self.analyze_button.setEnabled(True)
        
        # Update progress label
        self.progress_label.setText(f"Analysis complete. Analyzed {len(self.results)} URLs.")
        
        logger.info(f"Bulk analysis completed for {len(self.results)} URLs")
    
    def update_summary(self):
        """Update summary labels"""
        # Count classifications
        total = len(self.results)
        phishing = sum(1 for r in self.results if r.get('classification') == 'Phishing')
        suspicious = sum(1 for r in self.results if r.get('classification') == 'Suspicious')
        legitimate = sum(1 for r in self.results if r.get('classification') == 'Legitimate')
        
        # Update labels
        self.total_label.setText(f"Total: {total}")
        self.phishing_label.setText(f"Phishing: {phishing}")
        self.suspicious_label.setText(f"Suspicious: {suspicious}")
        self.legitimate_label.setText(f"Legitimate: {legitimate}")
    
    def export_results(self):
        """Export analysis results"""
        if not self.results:
            QMessageBox.information(self, "Export", "No analysis results to export.")
            return
        
        # Get file path
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Results", "", "CSV Files (*.csv);;JSON Files (*.json);;HTML Files (*.html);;All Files (*)"
        )
        
        if not file_path:
            return
        
        try:
            # Export based on file extension
            if file_path.lower().endswith('.json'):
                self._export_json(file_path)
            elif file_path.lower().endswith('.html'):
                self._export_html(file_path)
            else:
                self._export_csv(file_path)
            
            QMessageBox.information(self, "Export Successful", f"Results exported to {file_path}")
            logger.info(f"Bulk analysis results exported to {file_path}")
        
        except Exception as e:
            logger.error(f"Error exporting results: {str(e)}")
            QMessageBox.critical(self, "Export Error", f"Error exporting results: {str(e)}")
    
    def _export_json(self, file_path):
        """
        Export results as JSON
        
        Args:
            file_path (str): File path to export to
        """
        import json
        
        # Write to file
        with open(file_path, 'w') as f:
            json.dump(self.results, f, indent=2, default=str)
    
    def _export_csv(self, file_path):
        """
        Export results as CSV
        
        Args:
            file_path (str): File path to export to
        """
        import csv
        
        # Write to file
        with open(file_path, 'w', newline='') as f:
            writer = csv.writer(f)
            
            # Write header
            writer.writerow(['URL', 'Classification', 'Confidence', 'Risk Factors', 'Safety Factors'])
            
            # Write data
            for result in self.results:
                writer.writerow([
                    result.get('url', 'Unknown'),
                    result.get('classification', 'Unknown'),
                    f"{result.get('confidence', 0.0):.1%}",
                    ", ".join(result.get('risk_factors', [])),
                    ", ".join(result.get('safety_factors', []))
                ])
    
    def _export_html(self, file_path):
        """
        Export results as HTML
        
        Args:
            file_path (str): File path to export to
        """
        # Build HTML content
        html = """
        <!DOCTYPE html>
        <html>
        <head>
            <title>PhishGuard Bulk Analysis Report</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                h1 { color: #333; }
                table { border-collapse: collapse; width: 100%; margin-top: 20px; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                th { background-color: #f2f2f2; }
                .phishing { color: red; }
                .suspicious { color: orange; }
                .legitimate { color: green; }
                .summary { margin-top: 20px; margin-bottom: 20px; }
            </style>
        </head>
        <body>
            <h1>PhishGuard Bulk Analysis Report</h1>
            
            <div class="summary">
                <p><strong>Total URLs:</strong> {total}</p>
                <p><strong>Phishing:</strong> <span class="phishing">{phishing}</span></p>
                <p><strong>Suspicious:</strong> <span class="suspicious">{suspicious}</span></p>
                <p><strong>Legitimate:</strong> <span class="legitimate">{legitimate}</span></p>
            </div>
            
            <table>
                <tr>
                    <th>URL</th>
                    <th>Classification</th>
                    <th>Confidence</th>
                    <th>Risk Factors</th>
                    <th>Safety Factors</th>
                </tr>
        """.format(
            total=len(self.results),
            phishing=sum(1 for r in self.results if r.get('classification') == 'Phishing'),
            suspicious=sum(1 for r in self.results if r.get('classification') == 'Suspicious'),
            legitimate=sum(1 for r in self.results if r.get('classification') == 'Legitimate')
        )
        
        # Add rows for each result
        for result in self.results:
            classification = result.get('classification', 'Unknown')
            class_name = classification.lower()
            
            html += f"""
                <tr>
                    <td>{result.get('url', 'Unknown')}</td>
                    <td class="{class_name}">{classification}</td>
                    <td>{result.get('confidence', 0.0):.1%}</td>
                    <td>{"<br>".join(result.get('risk_factors', ['None']))}</td>
                    <td>{"<br>".join(result.get('safety_factors', ['None']))}</td>
                </tr>
            """
        
        html += """
            </table>
            
            <p><em>Generated by PhishGuard - Advanced Fake URL Detection Tool</em></p>
        </body>
        </html>
        """
        
        # Write to file
        with open(file_path, 'w') as f:
            f.write(html)
    
    def load_url_file(self, file_path):
        """
        Load URLs from a file
        
        Args:
            file_path (str): Path to file containing URLs
        """
        try:
            # Read URLs from file
            with open(file_path, 'r') as f:
                urls = [line.strip() for line in f if line.strip()]
            
            # Set URLs in text area
            self.url_input.setText("\n".join(urls))
            
            # Update status
            self.progress_label.setText(f"Loaded {len(urls)} URLs from file")
            
            logger.info(f"Loaded {len(urls)} URLs from {file_path}")
        
        except Exception as e:
            logger.error(f"Error loading URLs from file: {str(e)}")
            QMessageBox.critical(self, "Load Error", f"Error loading URLs from file: {str(e)}")

# Import QApplication for clipboard access
from PyQt5.QtWidgets import QApplication
