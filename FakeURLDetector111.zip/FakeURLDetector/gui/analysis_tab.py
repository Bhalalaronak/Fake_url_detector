#!/usr/bin/env python3
"""
Analysis Tab
Tab for analyzing individual URLs
"""

import logging
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                            QLineEdit, QProgressBar, QGroupBox, QFormLayout, QTextEdit,
                            QTableWidget, QTableWidgetItem, QHeaderView, QFileDialog,
                            QMessageBox, QSplitter)
from PyQt5.QtGui import QFont, QColor, QPalette, QPixmap
from PyQt5.QtCore import Qt, QThread, pyqtSignal

logger = logging.getLogger(__name__)

class AnalysisThread(QThread):
    """Thread for URL analysis to prevent GUI freezing"""
    
    # Define signals
    analysis_complete = pyqtSignal(dict)
    analysis_error = pyqtSignal(str)
    
    def __init__(self, url_detector, url):
        """
        Initialize the analysis thread
        
        Args:
            url_detector: URL detector instance
            url (str): URL to analyze
        """
        super().__init__()
        self.url_detector = url_detector
        self.url = url
    
    def run(self):
        """Run the analysis"""
        try:
            # Analyze URL
            result = self.url_detector.analyze_url(self.url)
            
            # Emit result
            self.analysis_complete.emit(result)
        
        except Exception as e:
            # Emit error
            self.analysis_error.emit(str(e))
            logger.error(f"Error in analysis thread: {str(e)}", exc_info=True)

class AnalysisTab(QWidget):
    """Tab for analyzing individual URLs"""
    
    def __init__(self, url_detector):
        """
        Initialize the analysis tab
        
        Args:
            url_detector: URL detector instance
        """
        super().__init__()
        
        self.url_detector = url_detector
        self.current_result = None
        
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        # Create main layout
        main_layout = QVBoxLayout()
        
        # Create URL input section
        input_group = QGroupBox("URL Analysis")
        input_layout = QHBoxLayout()
        
        # URL input field
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("Enter URL to analyze (e.g., https://example.com)")
        self.url_input.returnPressed.connect(self.start_analysis)
        input_layout.addWidget(self.url_input, 1)
        
        # Analyze button
        self.analyze_button = QPushButton("Analyze")
        self.analyze_button.clicked.connect(self.start_analysis)
        input_layout.addWidget(self.analyze_button)
        
        # Clear button
        clear_button = QPushButton("Clear")
        clear_button.clicked.connect(self.clear_analysis)
        input_layout.addWidget(clear_button)
        
        input_group.setLayout(input_layout)
        main_layout.addWidget(input_group)
        
        # Create progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)
        
        # Create splitter for results
        results_splitter = QSplitter(Qt.Vertical)
        
        # Create result summary section
        self.summary_group = QGroupBox("Analysis Result")
        summary_layout = QFormLayout()
        
        # URL label
        self.url_label = QLabel()
        self.url_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.url_label.setWordWrap(True)
        summary_layout.addRow("URL:", self.url_label)
        
        # Classification label
        self.classification_label = QLabel()
        self.classification_label.setFont(QFont("Arial", 12, QFont.Bold))
        summary_layout.addRow("Classification:", self.classification_label)
        
        # Confidence label
        self.confidence_label = QLabel()
        summary_layout.addRow("Confidence:", self.confidence_label)
        
        # Risk factors
        self.risk_factors_label = QLabel()
        self.risk_factors_label.setWordWrap(True)
        summary_layout.addRow("Risk Factors:", self.risk_factors_label)
        
        # Safety factors
        self.safety_factors_label = QLabel()
        self.safety_factors_label.setWordWrap(True)
        summary_layout.addRow("Safety Factors:", self.safety_factors_label)
        
        self.summary_group.setLayout(summary_layout)
        results_splitter.addWidget(self.summary_group)
        
        # Create detailed analysis section
        details_group = QGroupBox("Detailed Analysis")
        details_layout = QVBoxLayout()
        
        # Create table for features
        self.features_table = QTableWidget()
        self.features_table.setColumnCount(2)
        self.features_table.setHorizontalHeaderLabels(["Feature", "Value"])
        self.features_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.features_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        details_layout.addWidget(self.features_table)
        
        details_group.setLayout(details_layout)
        results_splitter.addWidget(details_group)
        
        # Add splitter to main layout
        main_layout.addWidget(results_splitter, 1)  # Give it stretch factor
        
        # Create button layout
        button_layout = QHBoxLayout()
        
        # Export button
        export_button = QPushButton("Export Results")
        export_button.clicked.connect(self.export_results)
        button_layout.addWidget(export_button)
        
        # Add to history button
        history_button = QPushButton("Add to History")
        history_button.clicked.connect(self.add_to_history)
        button_layout.addWidget(history_button)
        
        main_layout.addLayout(button_layout)
        
        self.setLayout(main_layout)
        
        # Initially hide the results
        self.summary_group.setVisible(False)
        details_group.setVisible(False)
    
    def set_url(self, url):
        """
        Set the URL to analyze
        
        Args:
            url (str): URL to analyze
        """
        self.url_input.setText(url)
    
    def start_analysis(self):
        """Start URL analysis"""
        # Get URL from input
        url = self.url_input.text().strip()
        
        if not url:
            QMessageBox.warning(self, "Input Error", "Please enter a URL to analyze.")
            return
        
        # Add http:// if no scheme is provided
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
            self.url_input.setText(url)
        
        # Show progress bar
        self.progress_bar.setVisible(True)
        
        # Disable analyze button
        self.analyze_button.setEnabled(False)
        
        # Clear previous results
        self.clear_result_display()
        
        # Create and start analysis thread
        self.analysis_thread = AnalysisThread(self.url_detector, url)
        self.analysis_thread.analysis_complete.connect(self.handle_analysis_complete)
        self.analysis_thread.analysis_error.connect(self.handle_analysis_error)
        self.analysis_thread.start()
        
        logger.info(f"Started analysis for URL: {url}")
    
    def handle_analysis_complete(self, result):
        """
        Handle analysis completion
        
        Args:
            result (dict): Analysis result
        """
        # Hide progress bar
        self.progress_bar.setVisible(False)
        
        # Enable analyze button
        self.analyze_button.setEnabled(True)
        
        # Store result
        self.current_result = result
        
        # Display result
        self.display_result(result)
        
        logger.info(f"Analysis completed for URL: {result.get('url', 'Unknown')}")
    
    def handle_analysis_error(self, error_message):
        """
        Handle analysis error
        
        Args:
            error_message (str): Error message
        """
        # Hide progress bar
        self.progress_bar.setVisible(False)
        
        # Enable analyze button
        self.analyze_button.setEnabled(True)
        
        # Show error message
        QMessageBox.critical(self, "Analysis Error", f"Error analyzing URL: {error_message}")
        
        logger.error(f"Analysis error: {error_message}")
    
    def display_result(self, result):
        """
        Display analysis result
        
        Args:
            result (dict): Analysis result
        """
        # Show summary group
        self.summary_group.setVisible(True)
        
        # Set URL
        self.url_label.setText(result.get('url', 'Unknown'))
        
        # Set classification with color
        classification = result.get('classification', 'Unknown')
        self.classification_label.setText(classification)
        
        if classification == 'Phishing':
            self.classification_label.setStyleSheet("color: red;")
        elif classification == 'Suspicious':
            self.classification_label.setStyleSheet("color: orange;")
        else:
            self.classification_label.setStyleSheet("color: green;")
        
        # Set confidence
        confidence = result.get('confidence', 0.0)
        self.confidence_label.setText(f"{confidence:.1%}")
        
        # Set risk factors
        risk_factors = result.get('risk_factors', [])
        if risk_factors:
            self.risk_factors_label.setText("\n".join(f"• {factor}" for factor in risk_factors))
        else:
            self.risk_factors_label.setText("None detected")
        
        # Set safety factors
        safety_factors = result.get('safety_factors', [])
        if safety_factors:
            self.safety_factors_label.setText("\n".join(f"• {factor}" for factor in safety_factors))
        else:
            self.safety_factors_label.setText("None detected")
        
        # Populate features table
        self.features_table.setRowCount(0)  # Clear table
        
        features = result.get('features', {})
        row = 0
        
        for key, value in features.items():
            self.features_table.insertRow(row)
            
            # Feature name
            name_item = QTableWidgetItem(key.replace('_', ' ').title())
            self.features_table.setItem(row, 0, name_item)
            
            # Feature value
            if isinstance(value, bool):
                value_text = "Yes" if value else "No"
            else:
                value_text = str(value)
            
            value_item = QTableWidgetItem(value_text)
            self.features_table.setItem(row, 1, value_item)
            
            row += 1
    
    def clear_result_display(self):
        """Clear the result display"""
        # Clear labels
        self.url_label.clear()
        self.classification_label.clear()
        self.classification_label.setStyleSheet("")
        self.confidence_label.clear()
        self.risk_factors_label.clear()
        self.safety_factors_label.clear()
        
        # Clear features table
        self.features_table.setRowCount(0)
        
        # Hide summary group
        self.summary_group.setVisible(False)
    
    def clear_analysis(self):
        """Clear the analysis"""
        # Clear input
        self.url_input.clear()
        
        # Clear result display
        self.clear_result_display()
        
        # Clear current result
        self.current_result = None
    
    def export_results(self):
        """Export analysis results"""
        if not self.current_result:
            QMessageBox.information(self, "Export", "No analysis results to export.")
            return
        
        # Get file path
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Results", "", "HTML Files (*.html);;JSON Files (*.json);;Text Files (*.txt);;All Files (*)"
        )
        
        if not file_path:
            return
        
        try:
            # Export based on file extension
            if file_path.lower().endswith('.html'):
                self._export_html(file_path)
            elif file_path.lower().endswith('.json'):
                self._export_json(file_path)
            else:
                self._export_text(file_path)
            
            QMessageBox.information(self, "Export Successful", f"Results exported to {file_path}")
            logger.info(f"Results exported to {file_path}")
        
        except Exception as e:
            QMessageBox.critical(self, "Export Error", f"Error exporting results: {str(e)}")
            logger.error(f"Error exporting results: {str(e)}")
    
    def _export_html(self, file_path):
        """
        Export results as HTML
        
        Args:
            file_path (str): File path to export to
        """
        result = self.current_result
        
        # Determine classification color
        classification = result.get('classification', 'Unknown')
        if classification == 'Phishing':
            color = "red"
        elif classification == 'Suspicious':
            color = "orange"
        else:
            color = "green"
        
        # Build HTML content
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>PhishGuard Analysis Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                h1 {{ color: #333; }}
                .result {{ margin-bottom: 20px; }}
                .classification {{ font-size: 18px; font-weight: bold; color: {color}; }}
                table {{ border-collapse: collapse; width: 100%; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
                .factors {{ margin-top: 10px; }}
                .factors ul {{ margin-top: 5px; }}
            </style>
        </head>
        <body>
            <h1>PhishGuard Analysis Report</h1>
            
            <div class="result">
                <h2>URL Analysis</h2>
                <p><strong>URL:</strong> {result.get('url', 'Unknown')}</p>
                <p><strong>Classification:</strong> <span class="classification">{classification}</span></p>
                <p><strong>Confidence:</strong> {result.get('confidence', 0.0):.1%}</p>
                
                <div class="factors">
                    <strong>Risk Factors:</strong>
                    <ul>
        """
        
        # Add risk factors
        risk_factors = result.get('risk_factors', [])
        if risk_factors:
            for factor in risk_factors:
                html += f"            <li>{factor}</li>\n"
        else:
            html += "            <li>None detected</li>\n"
        
        html += """
                    </ul>
                </div>
                
                <div class="factors">
                    <strong>Safety Factors:</strong>
                    <ul>
        """
        
        # Add safety factors
        safety_factors = result.get('safety_factors', [])
        if safety_factors:
            for factor in safety_factors:
                html += f"            <li>{factor}</li>\n"
        else:
            html += "            <li>None detected</li>\n"
        
        html += """
                    </ul>
                </div>
            </div>
            
            <h2>Detailed Features</h2>
            <table>
                <tr>
                    <th>Feature</th>
                    <th>Value</th>
                </tr>
        """
        
        # Add features
        features = result.get('features', {})
        for key, value in features.items():
            if isinstance(value, bool):
                value_text = "Yes" if value else "No"
            else:
                value_text = str(value)
            
            html += f"""
                <tr>
                    <td>{key.replace('_', ' ').title()}</td>
                    <td>{value_text}</td>
                </tr>
            """
        
        html += """
            </table>
            
            <p><em>Generated by PhishGuard - Advanced Fake URL Detection Tool</em></p>
        </body>
        </html>
        """
        
        # Write to file
        with open(file_path, 'w') as f:
            f.write(html)
    
    def _export_json(self, file_path):
        """
        Export results as JSON
        
        Args:
            file_path (str): File path to export to
        """
        import json
        
        # Write to file
        with open(file_path, 'w') as f:
            json.dump(self.current_result, f, indent=2, default=str)
    
    def _export_text(self, file_path):
        """
        Export results as plain text
        
        Args:
            file_path (str): File path to export to
        """
        result = self.current_result
        
        # Build text content
        text = "PhishGuard Analysis Report\n"
        text += "========================\n\n"
        
        text += f"URL: {result.get('url', 'Unknown')}\n"
        text += f"Classification: {result.get('classification', 'Unknown')}\n"
        text += f"Confidence: {result.get('confidence', 0.0):.1%}\n\n"
        
        text += "Risk Factors:\n"
        risk_factors = result.get('risk_factors', [])
        if risk_factors:
            for factor in risk_factors:
                text += f"- {factor}\n"
        else:
            text += "- None detected\n"
        
        text += "\nSafety Factors:\n"
        safety_factors = result.get('safety_factors', [])
        if safety_factors:
            for factor in safety_factors:
                text += f"- {factor}\n"
        else:
            text += "- None detected\n"
        
        text += "\nDetailed Features:\n"
        text += "=================\n\n"
        
        features = result.get('features', {})
        for key, value in features.items():
            if isinstance(value, bool):
                value_text = "Yes" if value else "No"
            else:
                value_text = str(value)
            
            text += f"{key.replace('_', ' ').title()}: {value_text}\n"
        
        text += "\nGenerated by PhishGuard - Advanced Fake URL Detection Tool"
        
        # Write to file
        with open(file_path, 'w') as f:
            f.write(text)
    
    def add_to_history(self):
        """Add current analysis to history"""
        if not self.current_result:
            QMessageBox.information(self, "History", "No analysis results to add to history.")
            return
        
        # The result is already stored in the database during analysis
        QMessageBox.information(self, "History", "Analysis added to history.")
        logger.info(f"Analysis added to history for URL: {self.current_result.get('url', 'Unknown')}")
