"""
GUI components for the PhishGuard application
"""
