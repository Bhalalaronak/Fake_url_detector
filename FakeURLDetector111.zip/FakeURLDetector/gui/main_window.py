#!/usr/bin/env python3
"""
Main Window
Main GUI window for the PhishGuard application
"""

import os
import logging
from PyQt5.QtWidgets import (QMainWindow, QTabWidget, QWidget, QVBoxLayout, QHBoxLayout,
                            QLabel, QPushButton, QLineEdit, QAction, QMessageBox,
                            QFileDialog, QTextEdit, QProgressBar, QStatusBar, QToolBar,
                            QComboBox, QCheckBox, QGroupBox, QFormLayout, QTableWidget,
                            QTableWidgetItem, QHeaderView, QSplitter, QMenu)
from PyQt5.QtGui import QIcon, QPixmap, QFont, QColor, QPalette
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QSize, QUrl

from .analysis_tab import AnalysisTab
from .history_tab import HistoryTab
from .settings_tab import SettingsTab
from .bulk_analysis_tab import BulkAnalysisTab
from .dashboard_tab import DashboardTab

logger = logging.getLogger(__name__)

class MainWindow(QMainWindow):
    """Main window for the PhishGuard application"""
    
    def __init__(self, url_detector, config):
        """
        Initialize the main window
        
        Args:
            url_detector: URL detector instance
            config (dict): Configuration dictionary
        """
        super().__init__()
        
        self.url_detector = url_detector
        self.config = config
        
        self.init_ui()
        
        logger.info("Main window initialized")
    
    def init_ui(self):
        """Initialize the user interface"""
        # Set window properties
        self.setWindowTitle("PhishGuard - Advanced Fake URL Detection Tool")
        self.setGeometry(100, 100, 1200, 800)
        
        # Set application icon
        icon_path = os.path.join('resources', 'images', 'icon.png')
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))
        
        # Create menu bar
        self.create_menu_bar()
        
        # Create toolbar
        self.create_toolbar()
        
        # Create status bar
        self.statusBar = QStatusBar()
        self.setStatusBar(self.statusBar)
        self.statusBar.showMessage("Ready")
        
        # Create central widget with tab layout
        self.central_widget = QTabWidget()
        self.setCentralWidget(self.central_widget)
        
        # Create tabs
        self.create_dashboard_tab()
        self.create_analysis_tab()
        self.create_bulk_analysis_tab()
        self.create_history_tab()
        self.create_settings_tab()
    
    def create_menu_bar(self):
        """Create the menu bar"""
        # File menu
        file_menu = self.menuBar().addMenu("&File")
        
        open_url_action = QAction("&Open URL...", self)
        open_url_action.setShortcut("Ctrl+O")
        open_url_action.triggered.connect(self.open_url)
        file_menu.addAction(open_url_action)
        
        open_file_action = QAction("Open URL &List...", self)
        open_file_action.setShortcut("Ctrl+L")
        open_file_action.triggered.connect(self.open_url_list)
        file_menu.addAction(open_file_action)
        
        file_menu.addSeparator()
        
        export_action = QAction("&Export Results...", self)
        export_action.setShortcut("Ctrl+E")
        export_action.triggered.connect(self.export_results)
        file_menu.addAction(export_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("E&xit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # Tools menu
        tools_menu = self.menuBar().addMenu("&Tools")
        
        clear_history_action = QAction("&Clear History", self)
        clear_history_action.triggered.connect(self.clear_history)
        tools_menu.addAction(clear_history_action)
        
        tools_menu.addSeparator()
        
        update_model_action = QAction("&Update Detection Model", self)
        update_model_action.triggered.connect(self.update_model)
        tools_menu.addAction(update_model_action)
        
        # Help menu
        help_menu = self.menuBar().addMenu("&Help")
        
        about_action = QAction("&About", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)
        
        help_action = QAction("&Help", self)
        help_action.setShortcut("F1")
        help_action.triggered.connect(self.show_help)
        help_menu.addAction(help_action)
    
    def create_toolbar(self):
        """Create the toolbar"""
        toolbar = QToolBar("Main Toolbar")
        toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(toolbar)
        
        # Add URL action
        analyze_action = QAction(QIcon.fromTheme("view-refresh", QIcon()), "Analyze URL", self)
        analyze_action.triggered.connect(self.analyze_url)
        toolbar.addAction(analyze_action)
        
        # Bulk analysis action
        bulk_action = QAction(QIcon.fromTheme("document-open", QIcon()), "Bulk Analysis", self)
        bulk_action.triggered.connect(self.bulk_analysis)
        toolbar.addAction(bulk_action)
        
        toolbar.addSeparator()
        
        # History action
        history_action = QAction(QIcon.fromTheme("document-properties", QIcon()), "History", self)
        history_action.triggered.connect(self.show_history)
        toolbar.addAction(history_action)
        
        # Settings action
        settings_action = QAction(QIcon.fromTheme("preferences-system", QIcon()), "Settings", self)
        settings_action.triggered.connect(self.show_settings)
        toolbar.addAction(settings_action)
    
    def create_dashboard_tab(self):
        """Create the dashboard tab"""
        self.dashboard_tab = DashboardTab(self.url_detector)
        self.central_widget.addTab(self.dashboard_tab, "Dashboard")
    
    def create_analysis_tab(self):
        """Create the analysis tab"""
        self.analysis_tab = AnalysisTab(self.url_detector)
        self.central_widget.addTab(self.analysis_tab, "URL Analysis")
    
    def create_bulk_analysis_tab(self):
        """Create the bulk analysis tab"""
        self.bulk_analysis_tab = BulkAnalysisTab(self.url_detector)
        self.central_widget.addTab(self.bulk_analysis_tab, "Bulk Analysis")
    
    def create_history_tab(self):
        """Create the history tab"""
        self.history_tab = HistoryTab(self.url_detector)
        self.central_widget.addTab(self.history_tab, "History")
    
    def create_settings_tab(self):
        """Create the settings tab"""
        self.settings_tab = SettingsTab(self.config)
        self.central_widget.addTab(self.settings_tab, "Settings")
    
    def open_url(self):
        """Open and analyze a URL"""
        # Switch to analysis tab
        self.central_widget.setCurrentWidget(self.analysis_tab)
        
        # Show URL input dialog
        from PyQt5.QtWidgets import QInputDialog
        url, ok = QInputDialog.getText(self, "Open URL", "Enter URL to analyze:")
        
        if ok and url:
            # Analyze the URL
            self.analysis_tab.set_url(url)
            self.analysis_tab.start_analysis()
    
    def open_url_list(self):
        """Open a list of URLs from a file"""
        # Switch to bulk analysis tab
        self.central_widget.setCurrentWidget(self.bulk_analysis_tab)
        
        # Open file dialog
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open URL List", "", "Text Files (*.txt);;CSV Files (*.csv);;All Files (*)"
        )
        
        if file_path:
            self.bulk_analysis_tab.load_url_file(file_path)
    
    def export_results(self):
        """Export analysis results"""
        # Get current tab
        current_tab = self.central_widget.currentWidget()
        
        # Call export method if available
        if hasattr(current_tab, 'export_results'):
            current_tab.export_results()
        else:
            QMessageBox.information(self, "Export", "No results to export from this tab.")
    
    def clear_history(self):
        """Clear analysis history"""
        reply = QMessageBox.question(
            self, "Clear History",
            "Are you sure you want to clear all analysis history?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            success = self.url_detector.db_manager.clear_history()
            
            if success:
                QMessageBox.information(self, "History Cleared", "Analysis history has been cleared.")
                
                # Refresh history tab
                self.history_tab.refresh_history()
                
                # Refresh dashboard
                self.dashboard_tab.refresh_dashboard()
            else:
                QMessageBox.critical(self, "Error", "Failed to clear history.")
    
    def update_model(self):
        """Update the detection model"""
        QMessageBox.information(
            self, "Update Model",
            "This feature is not implemented in the demo version."
        )
    
    def analyze_url(self):
        """Analyze a URL (toolbar action)"""
        # Switch to analysis tab
        self.central_widget.setCurrentWidget(self.analysis_tab)
    
    def bulk_analysis(self):
        """Perform bulk analysis (toolbar action)"""
        # Switch to bulk analysis tab
        self.central_widget.setCurrentWidget(self.bulk_analysis_tab)
    
    def show_history(self):
        """Show history (toolbar action)"""
        # Switch to history tab
        self.central_widget.setCurrentWidget(self.history_tab)
        
        # Refresh history
        self.history_tab.refresh_history()
    
    def show_settings(self):
        """Show settings (toolbar action)"""
        # Switch to settings tab
        self.central_widget.setCurrentWidget(self.settings_tab)
    
    def show_about(self):
        """Show about dialog"""
        QMessageBox.about(
            self, "About PhishGuard",
            "<h1>PhishGuard</h1>"
            "<p>Version 1.0.0</p>"
            "<p>An advanced cybersecurity tool designed to detect and analyze "
            "potentially malicious URLs, phishing websites, and fake domains.</p>"
            "<p>© 2023 PhishGuard Project</p>"
        )
    
    def show_help(self):
        """Show help dialog"""
        help_text = """
        <h1>PhishGuard Help</h1>
        
        <h2>URL Analysis</h2>
        <p>Enter a URL in the input field and click "Analyze" to check if it's potentially malicious.</p>
        
        <h2>Bulk Analysis</h2>
        <p>Analyze multiple URLs at once by entering them in the text area or loading from a file.</p>
        
        <h2>History</h2>
        <p>View your previous URL analysis results and statistics.</p>
        
        <h2>Settings</h2>
        <p>Configure application settings and detection parameters.</p>
        
        <h2>Keyboard Shortcuts</h2>
        <ul>
            <li><b>Ctrl+O</b>: Open URL</li>
            <li><b>Ctrl+L</b>: Open URL list</li>
            <li><b>Ctrl+E</b>: Export results</li>
            <li><b>Ctrl+Q</b>: Exit application</li>
            <li><b>F1</b>: Show this help</li>
        </ul>
        """
        
        from PyQt5.QtWidgets import QDialog, QVBoxLayout, QTextBrowser, QPushButton
        
        dialog = QDialog(self)
        dialog.setWindowTitle("PhishGuard Help")
        dialog.setMinimumSize(600, 400)
        
        layout = QVBoxLayout()
        
        text_browser = QTextBrowser()
        text_browser.setHtml(help_text)
        layout.addWidget(text_browser)
        
        close_button = QPushButton("Close")
        close_button.clicked.connect(dialog.accept)
        layout.addWidget(close_button)
        
        dialog.setLayout(layout)
        dialog.exec_()
