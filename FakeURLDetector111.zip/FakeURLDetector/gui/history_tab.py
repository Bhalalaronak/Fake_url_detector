#!/usr/bin/env python3
"""
History Tab
Tab for displaying analysis history
"""

import logging
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                            QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox,
                            QFileDialog)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt

logger = logging.getLogger(__name__)

class HistoryTab(QWidget):
    """Tab for displaying analysis history"""
    
    def __init__(self, url_detector):
        """
        Initialize the history tab
        
        Args:
            url_detector: URL detector instance
        """
        super().__init__()
        
        self.url_detector = url_detector
        
        self.init_ui()
        
        # Load history
        self.refresh_history()
    
    def init_ui(self):
        """Initialize the user interface"""
        # Create main layout
        main_layout = QVBoxLayout()
        
        # Create history table
        self.history_table = QTableWidget()
        self.history_table.setColumnCount(4)
        self.history_table.setHorizontalHeaderLabels(["URL", "Classification", "Confidence", "Timestamp"])
        
        # Set column widths
        self.history_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.history_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.history_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        
        # Enable sorting
        self.history_table.setSortingEnabled(True)
        
        main_layout.addWidget(self.history_table)
        
        # Create button layout
        button_layout = QHBoxLayout()
        
        # Refresh button
        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self.refresh_history)
        button_layout.addWidget(refresh_button)
        
        # Export button
        export_button = QPushButton("Export History")
        export_button.clicked.connect(self.export_history)
        button_layout.addWidget(export_button)
        
        # Clear button
        clear_button = QPushButton("Clear History")
        clear_button.clicked.connect(self.clear_history)
        button_layout.addWidget(clear_button)
        
        main_layout.addLayout(button_layout)
        
        self.setLayout(main_layout)
    
    def refresh_history(self):
        """Refresh history data"""
        try:
            # Get history from database
            history = self.url_detector.db_manager.get_analysis_history()
            
            # Clear table
            self.history_table.setRowCount(0)
            
            # Add history items to table
            for i, entry in enumerate(history):
                self.history_table.insertRow(i)
                
                # URL
                url_item = QTableWidgetItem(entry['url'])
                self.history_table.setItem(i, 0, url_item)
                
                # Classification
                classification = entry['classification']
                classification_item = QTableWidgetItem(classification)
                
                # Set color based on classification
                if classification == 'Phishing':
                    classification_item.setForeground(QColor('red'))
                elif classification == 'Suspicious':
                    classification_item.setForeground(QColor('orange'))
                else:
                    classification_item.setForeground(QColor('green'))
                
                self.history_table.setItem(i, 1, classification_item)
                
                # Confidence
                confidence = entry['confidence']
                confidence_item = QTableWidgetItem(f"{confidence:.1%}")
                self.history_table.setItem(i, 2, confidence_item)
                
                # Timestamp
                timestamp_item = QTableWidgetItem(entry['timestamp'])
                self.history_table.setItem(i, 3, timestamp_item)
            
            logger.info(f"Loaded {len(history)} history items")
        
        except Exception as e:
            logger.error(f"Error refreshing history: {str(e)}")
            QMessageBox.critical(self, "Error", f"Error refreshing history: {str(e)}")
    
    def export_history(self):
        """Export history to a file"""
        # Get file path
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export History", "", "CSV Files (*.csv);;JSON Files (*.json);;All Files (*)"
        )
        
        if not file_path:
            return
        
        try:
            # Get history from database
            history = self.url_detector.db_manager.get_analysis_history()
            
            # Export based on file extension
            if file_path.lower().endswith('.json'):
                self._export_json(history, file_path)
            else:
                self._export_csv(history, file_path)
            
            QMessageBox.information(self, "Export Successful", f"History exported to {file_path}")
            logger.info(f"History exported to {file_path}")
        
        except Exception as e:
            logger.error(f"Error exporting history: {str(e)}")
            QMessageBox.critical(self, "Export Error", f"Error exporting history: {str(e)}")
    
    def _export_json(self, history, file_path):
        """
        Export history as JSON
        
        Args:
            history (list): History data
            file_path (str): File path to export to
        """
        import json
        
        # Convert to serializable format
        serializable_history = []
        for entry in history:
            serializable_entry = dict(entry)
            serializable_entry['confidence'] = float(entry['confidence'])
            serializable_history.append(serializable_entry)
        
        # Write to file
        with open(file_path, 'w') as f:
            json.dump(serializable_history, f, indent=2, default=str)
    
    def _export_csv(self, history, file_path):
        """
        Export history as CSV
        
        Args:
            history (list): History data
            file_path (str): File path to export to
        """
        import csv
        
        # Write to file
        with open(file_path, 'w', newline='') as f:
            writer = csv.writer(f)
            
            # Write header
            writer.writerow(['URL', 'Classification', 'Confidence', 'Timestamp'])
            
            # Write data
            for entry in history:
                writer.writerow([
                    entry['url'],
                    entry['classification'],
                    f"{entry['confidence']:.1%}",
                    entry['timestamp']
                ])
    
    def clear_history(self):
        """Clear analysis history"""
        # Confirm clear
        reply = QMessageBox.question(
            self, "Clear History",
            "Are you sure you want to clear all analysis history?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        
        if reply == QMessageBox.No:
            return
        
        try:
            # Clear history in database
            success = self.url_detector.db_manager.clear_history()
            
            if success:
                # Refresh table
                self.history_table.setRowCount(0)
                
                QMessageBox.information(self, "History Cleared", "Analysis history has been cleared.")
                logger.info("Analysis history cleared")
            else:
                QMessageBox.critical(self, "Error", "Failed to clear history.")
        
        except Exception as e:
            logger.error(f"Error clearing history: {str(e)}")
            QMessageBox.critical(self, "Error", f"Error clearing history: {str(e)}")
