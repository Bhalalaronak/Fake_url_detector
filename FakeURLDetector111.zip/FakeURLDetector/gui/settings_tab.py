#!/usr/bin/env python3
"""
Settings Tab
Tab for configuring application settings
"""

import logging
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                            QGroupBox, QFormLayout, QLineEdit, QSpinBox, QDoubleSpinBox,
                            QCheckBox, QComboBox, QTabWidget, QFileDialog, QMessageBox)
from PyQt5.QtCore import Qt

from utils.config import save_config

logger = logging.getLogger(__name__)

class SettingsTab(QWidget):
    """Tab for configuring application settings"""
    
    def __init__(self, config):
        """
        Initialize the settings tab
        
        Args:
            config (dict): Configuration dictionary
        """
        super().__init__()
        
        self.config = config
        
        self.init_ui()
    
    def init_ui(self):
        """Initialize the user interface"""
        # Create main layout
        main_layout = QVBoxLayout()
        
        # Create tabs for different settings
        settings_tabs = QTabWidget()
        
        # General settings tab
        general_tab = self._create_general_tab()
        settings_tabs.addTab(general_tab, "General")
        
        # Detection settings tab
        detection_tab = self._create_detection_tab()
        settings_tabs.addTab(detection_tab, "Detection")
        
        # Analysis settings tab
        analysis_tab = self._create_analysis_tab()
        settings_tabs.addTab(analysis_tab, "Analysis")
        
        # Database settings tab
        database_tab = self._create_database_tab()
        settings_tabs.addTab(database_tab, "Database")
        
        main_layout.addWidget(settings_tabs)
        
        # Create button layout
        button_layout = QHBoxLayout()
        
        # Save button
        save_button = QPushButton("Save Settings")
        save_button.clicked.connect(self.save_settings)
        button_layout.addWidget(save_button)
        
        # Reset button
        reset_button = QPushButton("Reset to Defaults")
        reset_button.clicked.connect(self.reset_settings)
        button_layout.addWidget(reset_button)
        
        main_layout.addLayout(button_layout)
        
        self.setLayout(main_layout)
    
    def _create_general_tab(self):
        """Create the general settings tab"""
        tab = QWidget()
        layout = QFormLayout()
        
        # UI theme
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["system", "light", "dark"])
        self.theme_combo.setCurrentText(self.config.get('ui', {}).get('theme', 'system'))
        layout.addRow("UI Theme:", self.theme_combo)
        
        # Show tooltips
        self.tooltips_checkbox = QCheckBox()
        self.tooltips_checkbox.setChecked(self.config.get('ui', {}).get('show_tooltips', True))
        layout.addRow("Show Tooltips:", self.tooltips_checkbox)
        
        # Max history items
        self.max_history_spin = QSpinBox()
        self.max_history_spin.setRange(10, 1000)
        self.max_history_spin.setValue(self.config.get('ui', {}).get('max_history_items', 100))
        layout.addRow("Max History Items:", self.max_history_spin)
        
        tab.setLayout(layout)
        return tab
    
    def _create_detection_tab(self):
        """Create the detection settings tab"""
        tab = QWidget()
        layout = QFormLayout()
        
        # Phishing threshold
        self.phishing_threshold_spin = QDoubleSpinBox()
        self.phishing_threshold_spin.setRange(0.1, 1.0)
        self.phishing_threshold_spin.setSingleStep(0.05)
        self.phishing_threshold_spin.setValue(self.config.get('detection', {}).get('phishing_threshold', 0.7))
        layout.addRow("Phishing Threshold:", self.phishing_threshold_spin)
        
        # Suspicious threshold
        self.suspicious_threshold_spin = QDoubleSpinBox()
        self.suspicious_threshold_spin.setRange(0.1, 1.0)
        self.suspicious_threshold_spin.setSingleStep(0.05)
        self.suspicious_threshold_spin.setValue(self.config.get('detection', {}).get('suspicious_threshold', 0.4))
        layout.addRow("Suspicious Threshold:", self.suspicious_threshold_spin)
        
        # Model path
        self.model_path_input = QLineEdit()
        self.model_path_input.setText(self.config.get('model', {}).get('path', 'resources/models/url_classifier.joblib'))
        
        model_path_layout = QHBoxLayout()
        model_path_layout.addWidget(self.model_path_input)
        
        browse_model_button = QPushButton("Browse")
        browse_model_button.clicked.connect(self._browse_model_path)
        model_path_layout.addWidget(browse_model_button)
        
        layout.addRow("Model Path:", model_path_layout)
        
        tab.setLayout(layout)
        return tab
    
    def _create_analysis_tab(self):
        """Create the analysis settings tab"""
        tab = QWidget()
        layout = QFormLayout()
        
        # Analyze content
        self.analyze_content_checkbox = QCheckBox()
        self.analyze_content_checkbox.setChecked(self.config.get('analysis', {}).get('analyze_content', True))
        layout.addRow("Analyze Page Content:", self.analyze_content_checkbox)
        
        # Request timeout
        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(1, 60)
        self.timeout_spin.setValue(self.config.get('analysis', {}).get('request_timeout', 5))
        layout.addRow("Request Timeout (seconds):", self.timeout_spin)
        
        # Force reanalysis
        self.force_reanalysis_checkbox = QCheckBox()
        self.force_reanalysis_checkbox.setChecked(self.config.get('analysis', {}).get('force_reanalysis', False))
        layout.addRow("Force Reanalysis:", self.force_reanalysis_checkbox)
        
        # Suspicious TLDs
        self.suspicious_tlds_input = QLineEdit()
        suspicious_tlds = self.config.get('analysis', {}).get('suspicious_tlds', [])
        self.suspicious_tlds_input.setText(", ".join(suspicious_tlds))
        layout.addRow("Suspicious TLDs:", self.suspicious_tlds_input)
        
        # Suspicious keywords
        self.suspicious_keywords_input = QLineEdit()
        suspicious_keywords = self.config.get('analysis', {}).get('suspicious_keywords', [])
        self.suspicious_keywords_input.setText(", ".join(suspicious_keywords))
        layout.addRow("Suspicious Keywords:", self.suspicious_keywords_input)
        
        tab.setLayout(layout)
        return tab
    
    def _create_database_tab(self):
        """Create the database settings tab"""
        tab = QWidget()
        layout = QFormLayout()
        
        # Database path
        self.db_path_input = QLineEdit()
        self.db_path_input.setText(self.config.get('database', {}).get('path', 'data/phishguard.db'))
        
        db_path_layout = QHBoxLayout()
        db_path_layout.addWidget(self.db_path_input)
        
        browse_db_button = QPushButton("Browse")
        browse_db_button.clicked.connect(self._browse_db_path)
        db_path_layout.addWidget(browse_db_button)
        
        layout.addRow("Database Path:", db_path_layout)
        
        # Warning label
        warning_label = QLabel(
            "Warning: Changing the database path will require a restart "
            "and may result in loss of access to existing analysis history."
        )
        warning_label.setWordWrap(True)
        warning_label.setStyleSheet("color: red;")
        layout.addRow(warning_label)
        
        tab.setLayout(layout)
        return tab
    
    def _browse_model_path(self):
        """Browse for model file"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Model File", "", "Model Files (*.joblib *.pkl);;All Files (*)"
        )
        
        if file_path:
            self.model_path_input.setText(file_path)
    
    def _browse_db_path(self):
        """Browse for database file"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Select Database File", "", "Database Files (*.db);;All Files (*)"
        )
        
        if file_path:
            self.db_path_input.setText(file_path)
    
    def save_settings(self):
        """Save settings"""
        # Update config with form values
        
        # General settings
        if 'ui' not in self.config:
            self.config['ui'] = {}
        
        self.config['ui']['theme'] = self.theme_combo.currentText()
        self.config['ui']['show_tooltips'] = self.tooltips_checkbox.isChecked()
        self.config['ui']['max_history_items'] = self.max_history_spin.value()
        
        # Detection settings
        if 'detection' not in self.config:
            self.config['detection'] = {}
        
        self.config['detection']['phishing_threshold'] = self.phishing_threshold_spin.value()
        self.config['detection']['suspicious_threshold'] = self.suspicious_threshold_spin.value()
        
        if 'model' not in self.config:
            self.config['model'] = {}
        
        self.config['model']['path'] = self.model_path_input.text()
        
        # Analysis settings
        if 'analysis' not in self.config:
            self.config['analysis'] = {}
        
        self.config['analysis']['analyze_content'] = self.analyze_content_checkbox.isChecked()
        self.config['analysis']['request_timeout'] = self.timeout_spin.value()
        self.config['analysis']['force_reanalysis'] = self.force_reanalysis_checkbox.isChecked()
        
        # Parse suspicious TLDs
        suspicious_tlds = [tld.strip() for tld in self.suspicious_tlds_input.text().split(',') if tld.strip()]
        self.config['analysis']['suspicious_tlds'] = suspicious_tlds
        
        # Parse suspicious keywords
        suspicious_keywords = [kw.strip() for kw in self.suspicious_keywords_input.text().split(',') if kw.strip()]
        self.config['analysis']['suspicious_keywords'] = suspicious_keywords
        
        # Database settings
        if 'database' not in self.config:
            self.config['database'] = {}
        
        self.config['database']['path'] = self.db_path_input.text()
        
        # Save config to file
        if save_config(self.config):
            QMessageBox.information(self, "Settings Saved", "Settings have been saved successfully.")
            logger.info("Settings saved")
        else:
            QMessageBox.critical(self, "Error", "Failed to save settings.")
    
    def reset_settings(self):
        """Reset settings to defaults"""
        # Confirm reset
        reply = QMessageBox.question(
            self, "Reset Settings",
            "Are you sure you want to reset all settings to defaults?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        
        if reply == QMessageBox.No:
            return
        
        # Reset config to defaults
        from utils.config import get_default_config
        self.config = get_default_config()
        
        # Reload UI
        self.init_ui()
        
        QMessageBox.information(self, "Settings Reset", "Settings have been reset to defaults.")
        logger.info("Settings reset to defaults")
