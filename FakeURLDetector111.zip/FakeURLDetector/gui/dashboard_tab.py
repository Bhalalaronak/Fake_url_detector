#!/usr/bin/env python3
"""
Dashboard Tab
Tab for displaying dashboard information
"""

import logging
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
                            QGroupBox, QFormLayout, QLineEdit, QProgressBar, QTableWidget,
                            QTableWidgetItem, QHeaderView)
from PyQt5.QtGui import QFont, QColor, QPalette
from PyQt5.QtCore import Qt, QTimer

logger = logging.getLogger(__name__)

class DashboardTab(QWidget):
    """Tab for displaying dashboard information"""
    
    def __init__(self, url_detector):
        """
        Initialize the dashboard tab
        
        Args:
            url_detector: URL detector instance
        """
        super().__init__()
        
        self.url_detector = url_detector
        
        self.init_ui()
        
        # Set up refresh timer
        self.refresh_timer = QTimer(self)
        self.refresh_timer.timeout.connect(self.refresh_dashboard)
        self.refresh_timer.start(30000)  # Refresh every 30 seconds
        
        # Initial refresh
        self.refresh_dashboard()
    
    def init_ui(self):
        """Initialize the user interface"""
        # Create main layout
        main_layout = QVBoxLayout()
        
        # Create statistics section
        stats_group = QGroupBox("Analysis Statistics")
        stats_layout = QHBoxLayout()
        
        # Create form layouts for statistics
        stats_form1 = QFormLayout()
        stats_form2 = QFormLayout()
        stats_form3 = QFormLayout()
        
        # Total URLs analyzed
        self.total_analyzed_label = QLabel("0")
        self.total_analyzed_label.setFont(QFont("Arial", 16, QFont.Bold))
        stats_form1.addRow("Total URLs Analyzed:", self.total_analyzed_label)
        
        # URLs analyzed today
        self.today_analyzed_label = QLabel("0")
        self.today_analyzed_label.setFont(QFont("Arial", 16, QFont.Bold))
        stats_form1.addRow("Analyzed Today:", self.today_analyzed_label)
        
        # Phishing URLs
        self.phishing_label = QLabel("0")
        self.phishing_label.setFont(QFont("Arial", 16, QFont.Bold))
        self.phishing_label.setStyleSheet("color: red;")
        stats_form2.addRow("Phishing URLs:", self.phishing_label)
        
        # Suspicious URLs
        self.suspicious_label = QLabel("0")
        self.suspicious_label.setFont(QFont("Arial", 16, QFont.Bold))
        self.suspicious_label.setStyleSheet("color: orange;")
        stats_form2.addRow("Suspicious URLs:", self.suspicious_label)
        
        # Legitimate URLs
        self.legitimate_label = QLabel("0")
        self.legitimate_label.setFont(QFont("Arial", 16, QFont.Bold))
        self.legitimate_label.setStyleSheet("color: green;")
        stats_form3.addRow("Legitimate URLs:", self.legitimate_label)
        
        # Add form layouts to stats layout
        stats_layout.addLayout(stats_form1)
        stats_layout.addLayout(stats_form2)
        stats_layout.addLayout(stats_form3)
        
        stats_group.setLayout(stats_layout)
        main_layout.addWidget(stats_group)
        
        # Create quick analysis section
        quick_group = QGroupBox("Quick URL Analysis")
        quick_layout = QHBoxLayout()
        
        # URL input
        self.quick_url_input = QLineEdit()
        self.quick_url_input.setPlaceholderText("Enter URL to analyze")
        self.quick_url_input.returnPressed.connect(self.quick_analyze)
        quick_layout.addWidget(self.quick_url_input, 1)
        
        # Analyze button
        analyze_button = QPushButton("Analyze")
        analyze_button.clicked.connect(self.quick_analyze)
        quick_layout.addWidget(analyze_button)
        
        quick_group.setLayout(quick_layout)
        main_layout.addWidget(quick_group)
        
        # Create recent analyses section
        recent_group = QGroupBox("Recent Analyses")
        recent_layout = QVBoxLayout()
        
        # Create table for recent analyses
        self.recent_table = QTableWidget()
        self.recent_table.setColumnCount(4)
        self.recent_table.setHorizontalHeaderLabels(["URL", "Classification", "Confidence", "Timestamp"])
        self.recent_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.recent_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.recent_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.recent_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeToContents)
        recent_layout.addWidget(self.recent_table)
        
        # Refresh button
        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self.refresh_dashboard)
        recent_layout.addWidget(refresh_button)
        
        recent_group.setLayout(recent_layout)
        main_layout.addWidget(recent_group, 1)  # Give it stretch factor
        
        self.setLayout(main_layout)
    
    def refresh_dashboard(self):
        """Refresh dashboard data"""
        try:
            # Get statistics
            stats = self.url_detector.db_manager.get_statistics()
            
            # Update statistics labels
            self.total_analyzed_label.setText(str(stats['total_analyzed']))
            self.today_analyzed_label.setText(str(stats['recent_count']))
            
            # Update classification counts
            classification_counts = stats['classification_counts']
            self.phishing_label.setText(str(classification_counts.get('Phishing', 0)))
            self.suspicious_label.setText(str(classification_counts.get('Suspicious', 0)))
            self.legitimate_label.setText(str(classification_counts.get('Legitimate', 0)))
            
            # Get recent analyses
            history = self.url_detector.db_manager.get_analysis_history(limit=10)
            
            # Update recent analyses table
            self.recent_table.setRowCount(0)  # Clear table
            
            for i, entry in enumerate(history):
                self.recent_table.insertRow(i)
                
                # URL
                url_item = QTableWidgetItem(entry['url'])
                self.recent_table.setItem(i, 0, url_item)
                
                # Classification
                classification = entry['classification']
                classification_item = QTableWidgetItem(classification)
                
                # Set color based on classification
                if classification == 'Phishing':
                    classification_item.setForeground(QColor('red'))
                elif classification == 'Suspicious':
                    classification_item.setForeground(QColor('orange'))
                else:
                    classification_item.setForeground(QColor('green'))
                
                self.recent_table.setItem(i, 1, classification_item)
                
                # Confidence
                confidence = entry['confidence']
                confidence_item = QTableWidgetItem(f"{confidence:.1%}")
                self.recent_table.setItem(i, 2, confidence_item)
                
                # Timestamp
                timestamp_item = QTableWidgetItem(entry['timestamp'])
                self.recent_table.setItem(i, 3, timestamp_item)
            
            logger.debug("Dashboard refreshed")
        
        except Exception as e:
            logger.error(f"Error refreshing dashboard: {str(e)}")
    
    def quick_analyze(self):
        """Perform quick analysis of URL"""
        # Get URL from input
        url = self.quick_url_input.text().strip()
        
        if not url:
            return
        
        # Add http:// if no scheme is provided
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
            self.quick_url_input.setText(url)
        
        # Switch to analysis tab
        main_window = self.window()
        if hasattr(main_window, 'central_widget') and hasattr(main_window.central_widget, 'setCurrentWidget'):
            for i in range(main_window.central_widget.count()):
                widget = main_window.central_widget.widget(i)
                if hasattr(widget, 'set_url') and hasattr(widget, 'start_analysis'):
                    main_window.central_widget.setCurrentWidget(widget)
                    widget.set_url(url)
                    widget.start_analysis()
                    break
